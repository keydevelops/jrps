It ya boi, new day new banger
-----
Ya swiggity broski dawg, its pretty lit hype you download this pog swag pack B))

to install this #fire datapack into your minecraft server, well you probs already no how my bro but just in case go to https://nodecraft.com/support/games/minecraft/how-to-add-datapacks-to-your-minecraft-server, and paste the "mcmoji" folder where it tells you to

to install this #pogchamp datapack into your singleplayer world (for some unknown reason), then paste the "mcmoji" file at C:\Users\[User]\AppData\Roaming\.minecraft\saves\[yourworld]\datapacks

for you and your bros and gals to have the pack work, your servermates will need to be using the #dabomb resource pack.
Just paste the file "MCmoji Resources" at C:\Users\[User]\AppData\Roaming\.minecraft\resourcepacks\

thanks broskis B;D)